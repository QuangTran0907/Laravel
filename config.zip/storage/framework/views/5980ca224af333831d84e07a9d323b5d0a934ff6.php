
 <?php $__env->startSection('content'); ?>
 <h1>This is index foods add in layout</h1>
 <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <h4><?php echo e($item->id); ?></h4>
     <h4><?php echo e($item->name); ?></h4>
    <a href="foods/create"><button type="button">Create </button></a>

    <form action="foods/<?php echo e($item->id); ?>/edit">
        <button type="submit">Edit</button>
    </form>
    <form action="foods/<?php echo e($item->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <button type="submit">Delete</button>
    </form>
    <br>
    <br>
    <br>

 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php $__env->stopSection(); ?>
  

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\lavavel-app\resources\views/foods/index.blade.php ENDPATH**/ ?>