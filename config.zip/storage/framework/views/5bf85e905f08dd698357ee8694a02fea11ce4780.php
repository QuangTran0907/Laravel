
 <?php $__env->startSection('content'); ?>
 <h1 class="h3 mb-2 text-gray-800">Thêm sản phẩm</h1>
 <form action="/products" method="post"
      enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <div class="form-group row">
    <div class="col-sm-7">

      <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">Tên</label>
        <div class="col-sm-9">
          <input type="" name="name" class="form-control" id="inputEmail3" placeholder="">
        </div>
      </div>
    
      <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">Hãng</label>
        <div class="col-sm-9">
          <select name="brand_id" class="custom-select ">
            <option selected>Chọn hãng</option>
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
          </select>
        </div>
      </div>
    
      <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">Giá</label>
        <div class="col-sm-9">
          <input type="" name="price" class="form-control" id="inputEmail3" placeholder="">
        </div>
        
      </div>

      <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">Mô tả</label>
        <div class="col-sm-9">
          <textarea class="form-control" id="exampleFormControlTextarea1" name="description" rows="3"></textarea>
        </div>
        
      </div>
      <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">Chọn ảnh</label>
        <div class="col-sm-9">
          <div class="mb-3">
            <input class="form-control" name="image" type="file" id="formFileMultiple" multiple>
          </div>
        </div>
        
      </div>
    
      
    
      <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">Năm phát hành</label>
        <div class="col-sm-4">
          <input type="text" name="release_year" class="form-control" name="datepicker" id="datepicker" />
        </div>
    
        
      </div>
      <fieldset class="form-group">
        <div class="row">
          <legend class="col-form-label col-sm-2 pt-0">Màu sắc</legend>
          <div class="col-sm-10">
            <div class="form-check ">
              <input class="form-check-input" type="radio" name="color" id="color" value="red" checked>
              <label class="form-check-label" for="color">
                First radio
              </label>
            </div>
          </div>
    
          
        </div>
      </fieldset>
      <div class="form-group row">
        <div class="col-sm-2">Checkbox</div>
        <div class="col-sm-10">
          <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
          <div class="form-group row">
            <div class="form-check col-sm-3">
            
              <div class="col-sm-10">
                <input name="<?php echo e($item->id); ?>" class="form-check-input" type="checkbox" onclick="onCheck<?php echo e($item->id); ?>()" id="gridCheck<?php echo e($item->id); ?>">
                <label class="form-check-label" for="gridCheck1">
                  <?php echo e($item->size."------:"); ?>       
                </label>            </div>
            </div>
            

            <div class="col-sm-4" id="demo<?php echo e($item->id); ?>">
            </div>
          </div>
          <script>
            function onCheck<?php echo e($item->id); ?>()
            {
              var flag = document.getElementById("gridCheck<?php echo e($item->id); ?>").checked;
              if(flag==true)
              {
                document.getElementById("demo<?php echo e($item->id); ?>").innerHTML = '<input type="text" name="<?php echo e($item->id."SL"); ?>" class="form-control"  id="datepicker" />';

              }else
              {
                document.getElementById("demo<?php echo e($item->id); ?>").innerHTML = '';
              }
            }
              
          </script>

          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
      </div>
    

    </div>
    <div class="col-sm-5">
      <div class="promotion-image-container">
        <img src="https://via.placeholder.com/300x200" class="img-thumbnail">
      </div>
    </div>
    
  </div>
  <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Thêm mới</button>
    </div>
  </div>
</form>



 <?php $__env->stopSection(); ?>
  

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\lavavel-app\resources\views/products/create.blade.php ENDPATH**/ ?>