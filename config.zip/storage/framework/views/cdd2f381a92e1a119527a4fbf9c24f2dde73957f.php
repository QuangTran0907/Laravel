
 <?php $__env->startSection('content'); ?>
 
 <h1>Update the food</h1>
 <div class="container">
    <label for="form">Them mon an</label>
    <form action="/foods/<?php echo e($food->id); ?>" method="post" name="form">
       
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input type="text" class="form-control" name="name" value="<?php echo e($food->name); ?>" placeholder="Enter your name">
        <input type="text" class="form-control" name="sl" value="<?php echo e($food->sl); ?>" placeholder="Enter sl">
        <input type="text" class="form-control" name="description" value="<?php echo e($food->description); ?>" placeholder="Enter des">
        <select name="category_id" id="cars">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
          </select>

        <input class="button btn-primary" type="submit" value="submit">
     </form>
 </div>



 <?php $__env->stopSection(); ?>
  

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\lavavel-app\resources\views/foods/edit.blade.php ENDPATH**/ ?>