
 <?php $__env->startSection('content'); ?>
 <h1 class="h3 mb-2 text-gray-800">Thêm sản phẩm</h1>
 <form action="/products/save_media/<?php echo e($product->id); ?>" method="post"
      enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <div class="form-group row">
    <div class="col-sm-7">

      <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">Tên</label>
        <div class="col-sm-9">
          <input type="" name="name" value="<?php echo e($product->name); ?>" class="form-control" id="inputEmail3" placeholder="">
        </div>
      </div>
    
 
     
      

      <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">Chọn ảnh</label>
        <div class="col-sm-9">
          <div class="mb-3">
            <input class="form-control" name="image1" type="file" id="formFileMultiple" multiple>
          </div>
        </div>
        
      </div>

      <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">Chọn ảnh</label>
        <div class="col-sm-9">
          <div class="mb-3">
            <input class="form-control" name="image2" type="file" id="formFileMultiple" multiple>
          </div>
        </div>
        
      </div>

      <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">Chọn ảnh</label>
        <div class="col-sm-9">
          <div class="mb-3">
            <input class="form-control" name="image3" type="file" id="formFileMultiple" multiple>
          </div>
        </div>
        
      </div>

      <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">Chọn ảnh</label>
        <div class="col-sm-9">
          <div class="mb-3">
            <input class="form-control" name="image4" type="file" id="formFileMultiple" multiple>
          </div>
        </div>
        
      </div>
    
      
    
     
     
    

    </div>
 
    
  </div>
  <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Thêm mới</button>
    </div>
  </div>
</form>



 <?php $__env->stopSection(); ?>
  

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\lavavel-app\resources\views/products/add_image.blade.php ENDPATH**/ ?>